##############################
# Name: Hannah Luo
# UNI: hrl2116
#
# File contains functions regarding the percolation model in class
# in the air
##############################

# *******************************************************
# percolation module
# HW3 Part B
# ENGI E1006
# *******************************************************

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap


def read_grid(input_file):
    """Create a site vacancy matrix from a text file.

    input_file is a file object associated with the
    text file to be read. The method should return
    the corresponding site vacancy matrix represented
    as a numpy array
    """
    
    j = int (input_file.readline())
    
    lines = input_file.readlines()
    
    string = ""
    
    for i in range(j):
        string += lines[i]
        
    #utilize numpy to make a 1 x j matrix
    twodarray = np.array(string.split())
    
    #reshaping the 1 x j matrix vector
    twodarray.shape = (j, j)
    twodarray = twodarray.astype(int)
    
    
    #close file as you would close a scanner
    input_file.close()
    
    return twodarray
    
    pass


def write_grid(filename, sites):
    """Write a site vacancy matrix to a file.

    filename is a String that is the name of the
    text file to write to. sites is a numpy array
    representing the site vacany matrix to write
    """
    with open(filename, 'w') as fp:
        fp.write(str(len(sites)))
        fp.write('\n')
        np.savetxt(fp, sites, fmt="%d")


def percolate(mat, x, y):
    ''' recursive!! '''
    
    # check if valid for water to flow
    #   - in bounds of the matrix
    #   - not a 0 (blocked)
    #   - not a 2 (already filled with water)
    
    # mat[x,y] = 2
    
    # recurse
    
    
    #checking bounds
    #x on the graph is actually defined by the column number
    #counterintuitively, my x is actually on the vertical axis and my
    #y is on the horizontal axis
    if(x >= len(mat) or x < 0 or y >= len(mat[0]) or y < 0):
        pass
    #checking if it is blocked or already filled with water
    elif(mat[x,y] == 0 or mat[x,y] == 2):
        pass
    else:
        mat[x,y] = 2
        
        #recursive calls:
        #South
        percolate(mat, x+1, y)
        #West
        percolate(mat, x, y-1)
        #East
        percolate(mat, x, y+1)

def flow(sites):
    """Returns a matrix of vacant/full sites (1=vacant, 0=full)

    sites is a numpy array representing a site vacancy matrix. This
    function should return the corresponding flow matrix generated
    through vertical percolation
    """
    new_sites = sites.copy()
    
    for i in range(len(sites)):
        percolate(new_sites, 0, i)
    
    return new_sites

    pass
 

def percolates(flow_matrix):
    """Returns a boolean if the flow_matrix exhibits percolation

    flow_matrix is a numpy array representing a flow matrix
    """
    
    return any(flow_matrix[-1,:] == 2)
    pass


def make_sites(n, p):
    """Returns an nxn site vacancy matrix

    Generates a numpy array representing an nxn site vacancy
    matrix with site vaccancy probability p
    """
    return (np.random.random((n, n)) > (1 - p)).astype(int)


def plot(before, after):
    """Plots the before and after matrices using matplotlib
    """
    
    # don't touch the plot function, leave as is
    
    fig, axes = plt.subplots(1, 2)

    axes[0].pcolor(before, cmap='Greys_r')
    axes[0].set_ylim(before.shape[0], 0)

    l = ListedColormap(['black', 'white', 'blue'])
    axes[1].pcolor(after, cmap=l)
    axes[1].set_ylim(before.shape[0], 0)
    plt.show()
