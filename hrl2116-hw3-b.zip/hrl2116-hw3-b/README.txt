﻿Name: Hannah Luo
UNI: hrl2116
HW Number: 3B


Brief descriptions of the functions I implemented


Percolation:
* Read_grid:
   * First, I declare a int j which is the first line of the file and simply contains the dimensions of the matrix as an int
   * Then, I use a for loop to create a long string by concatenating all of the lines together
   * Then, I declare and initialize a numpy array, using the shape method to obtain my desired dimensions
* Write_grid:
   * I open the file and save the formatted text
* Percolate:
   * In this recursive method, I first check to see if the site we are checking is out of bounds by making sure that it is within the dimensions of the matrix.
   * Then, I check to make sure that it is not already filled with water or if it is blocked
   * If it continues past that point, then I change the value at that site to be a 2 (water flows)
   * Then, I make the recursive call to percolate its neighbors
   * Something important to note is that counterintuitively, x is my vertical axis and y is my horizontal axis on the graph since I defined x to be the row and y to be the column.
* Flow:
   * Returns the changed matrix after calling percolate on the first row
* Percolates:
   * Returns true if any of the values on the bottom row are a 2
* Make_sites:
   * Generates an nxn numpy matrix filled with random values, where each of the random values are made into 0s or 1s depending on if they are greater than 1-p
      * It’s 1-p instead of p because p is the probability that the site is vacant
Dataset:
* postProcessCSV:
   * Takes in dataset as the input and iterates through the dataset and removes the first column of every row (removes the client ID)
   * Iterates through the dataset and changes all of the float strings into floats by recasting them
* datasetInfo
   * Declares and initializes int variables benign and malignant at 0
   * Iterates through the dataset and checks to see if the first element is a B or an M
      * If B, then adds 1 to benign
      * If M, then adds 1 to malignant
   * Creates keys called benign and malignant and assigns them to their corresponding benign and malignant integer values
* splitDataset
   * Returns two lists
   * First list is the slice of the data set from the rounded number of the first test_percentage% values of the data set
   * Second list is the rest