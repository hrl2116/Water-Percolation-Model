##############################
# Name: Hannah Luo
# UNI: hrl2116
#
# File contains functions to analyze and edit a list of data
##############################

# *******************************************************
# dataset
# HW3 Part B
# ENGI E1006
# *******************************************************
def postProcessCSV(dataset):
    '''
    Takes the dataset as an N x M list of lists.

    Modifies the dataset in-place to:
        - strip the client ID
        - convert the float columns to be floats instead of strings
    '''
    
    #iterates through dataset and removes the first column in each row
    for row in dataset:
        row.pop(0)
    #iterates through the dataset and changes all the float strings to floats
    for row in dataset:
        for i in range(len(row)):
            if i == 0:
                continue
            row[i] = float(row[i])

def datasetInfo(dataset):
    '''
    Takes the dataset as an N x M list of lists.

    Returns the following statistics as a dictionary:
        rows: N from above, as an integer
        columns: M from above, as an integer
        benign: Number of benign entries in dataset
        malignant: Number of malignant entries in dataset
    '''
    # return a dictionary
    ret = {}

    ret['rows'] = len(dataset)
    ret['columns'] = len(dataset[0])
    # Fill in here

    benign = 0
    malignant = 0
    
    print(dataset)
    for row in dataset:
        if row[0] == 'B':
            benign += 1
        else:
            malignant += 1
    ret['benign'] = benign
    ret['malignant'] = malignant

    return ret


def splitDataset(dataset, test_percentage=20):
    '''
    Takes the dataset as an N x M list of lists.

    Returns 2 subsets of the dataset:
        the first is the testing part, which should be test_percentage percent of N
        the first is the training part, which should be 100-test_percentage percent of N
    '''
    # Fill in here
    # slices the first 20% and then the rest of the 80%
    return dataset[:round((test_percentage/100)*len(dataset))], \
    dataset[round((test_percentage/100)*len(dataset)):]