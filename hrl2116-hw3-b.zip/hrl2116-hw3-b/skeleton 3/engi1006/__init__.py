##############################
# Name: Hannah Luo
# UNI: hrl2116
#
# File is simply importing previously defined methods
##############################

# *******************************************************
# Dataset
# HW3 Part B
# ENGI E1006
# *******************************************************
from utils import parseCSV, askConfig
from data import datasetInfo, postProcessCSV, splitDataset
